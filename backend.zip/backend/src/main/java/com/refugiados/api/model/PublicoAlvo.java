package com.refugiados.api.model;

public enum PublicoAlvo {
    MULHERES,
    MENINAS
}
