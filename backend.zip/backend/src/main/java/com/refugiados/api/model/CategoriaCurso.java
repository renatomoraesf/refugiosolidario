package com.refugiados.api.model;

public enum CategoriaCurso {
    IDIOMA,
    PROFISSIONALIZANTE,
    EMPREENDEDORISMO,
    TECNOLOGIA,
    SAUDE,
    OUTROS;


}
