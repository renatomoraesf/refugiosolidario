package com.refugiados.api.repository;

import com.refugiados.api.model.ConteudoEspecifico;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ConteudoEspecificoRepository extends JpaRepository<ConteudoEspecifico, Long> {
}