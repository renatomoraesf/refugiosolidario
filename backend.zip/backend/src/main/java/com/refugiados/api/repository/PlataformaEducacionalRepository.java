package com.refugiados.api.repository;

import com.refugiados.api.model.PlataformaEducacional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PlataformaEducacionalRepository extends JpaRepository<PlataformaEducacional, Long> {
}