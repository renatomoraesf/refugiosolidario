package com.refugiados.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RefugiadosApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(RefugiadosApiApplication.class, args);
	}

}
